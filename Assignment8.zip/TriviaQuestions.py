#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50
#Decription: This program creates a function that creates a list of trivia questions and returns it

# importing class from questions.py
import questions

# creating a function called TriviaQuestions, which is a list of all the questions using Questions class from questions.py
def TriviaQuestions():
    questionlist = [] #empty list

    # appending each question into the list, follows parameters for questions.Questions()
    questionlist.append(questions.Questions('How many days are in a lunar year? ',
                                            '354',
                                            '365',
                                            '243',
                                            '370',
                                            1))

    questionlist.append(questions.Questions('What is the largest planet? ',
                                            'Mars',
                                            'Jupiter',
                                            'Earth',
                                            'Pluto',
                                            2))

    questionlist.append(questions.Questions('What is the largest kind of whale? ',
                                            'Orca whale',
                                            'Humpback whale',
                                            'Beluga whale',
                                            'Blue whale',
                                            4))

    questionlist.append(questions.Questions('Which dinosaur could fly? ',
                                            'Triceratops',
                                            'Tyrannosaurus Rex',
                                            'Pteranodon',
                                            'Diplodocus',
                                            3))

    questionlist.append(questions.Questions('Which of these Winnie the Pooh characters is a donkey? ',
                                            'Pooh',
                                            'Eeyore',
                                            'Piglet',
                                            'Kanga',
                                            2))

    questionlist.append(questions.Questions('What is the hottest planet',
                                            'Mars',
                                            'Pluto',
                                            'Earth',
                                            'Venus',
                                            4))

    questionlist.append(questions.Questions('Which dinosaur had the largest brain compared to body size? ',
                                            'Troodon',
                                            'Stegosaurus',
                                            'Ichthyosaurus',
                                            'Gigantoraptor',
                                            1))

    questionlist.append(questions.Questions('What is the largest type of penguins? ',
                                            'Chinstrap penguins',
                                            'Macaroni penguins',
                                            'Emperor penguins',
                                            'White-flippered penguins',
                                            3))

    questionlist.append(questions.Questions('Which children\'s story character is a monkey? ',
                                            'Winnie the Pooh',
                                            'Curious George',
                                            'Horton',
                                            'Goofy',
                                            2))

    questionlist.append(questions.Questions('How long is a year on Mars? ',
                                            '550 Earth days',
                                            '498 Earth days',
                                            '126 Earth days',
                                            '687 Earth days',
                                            4))
    # returning list of questions
    return questionlist


