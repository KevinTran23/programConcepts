#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50
#Decription: This program quizzes two users on 10 trivia questions and calculates who won

# driver program that will TriviaQuestions which imported questions class
import TriviaQuestions

# defining main to organize program
def main():
    # player scores
    player1 = 0
    player2 = 0
    # determining which player is going
    player1Turn = True
    # creating the object 'Trivia'
    Trivia = TriviaQuestions.TriviaQuestions()

    # iterating through the object
    for x in Trivia:
        # player 1 going
        if player1Turn == True:
            print('Question for the first player:')
            print(x)
            answer = int(input('Enter your solution (a number between 1 and 4): '))
            # correct
            if answer == x.getCorrect():
                player1 += 1
                print('That is the correct answer.')
                print()
            # incorrect
            else:
                print(f'That is incorrect. The correct answer is {x.getCorrect()}')
                print()
            player1Turn = False # at end of player1 loop, turn to False so player2 goes
        # player 2 going, follows same logic
        elif player1Turn == False:
            print('Question for the second player:')
            print(x)
            answer = int(input('Enter your solution (a number between 1 and 4): '))
            if answer == x.getCorrect():
                player2 += 1
                print('That is the correct answer.')
                print()
            else:
                print(f'That is incorrect. The correct answer is {x.getCorrect()}')
                print()
            player1Turn = True # player 1 turn

    # finish loop, compare scores and print corresponding statements
    if player1 == player2:
        print(f'The first player earned {player1} points.')
        print(f'The second player earned {player2} points.')
        print('It\'s a tie.')
    elif player1 > player2:
            print(f'The first player earned {player1} points.')
            print(f'The second player earned {player2} points.')
            print('The first player wins.')
    else:
        print(f'The first player earned {player1} points.')
        print(f'The second player earned {player2} points.')
        print('The second player wins.')

# calling main to start program
main()