#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50
#Decription: This program holds question class for use by the triva questions program

# creating the class for Questions, has the following parameters
class Questions:
    # constructor
    def __init__(self,question,ans1,ans2,ans3,ans4,corr_ans):
        self.__question = question
        self.__answer1 = ans1
        self.__answer2 = ans2
        self.__answer3 = ans3
        self.__answer4 = ans4
        self.__correct = corr_ans

    # accessor for the correct answer, to be used for comparing user input
    def getCorrect(self):
        return self.__correct

    # string method to print out formatted trivia question
    def __str__(self):
        return f'{self.__question}' \
               f'\n1. {self.__answer1}' \
               f'\n2. {self.__answer2}' \
               f'\n3. {self.__answer3}' \
               f'\n4. {self.__answer4}'

# end of class