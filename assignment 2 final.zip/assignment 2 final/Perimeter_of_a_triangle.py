#Ethan Tracy(Navigator)U806388874 Kevin (Driver)U56161476
#participation: 50/50
#perimeter of a triangle

#grabbing user input and setting them to variables
edge1 = float(input('Enter length of edge1: '))
edge2 = float(input('Enter length of edge2: '))
edge3 = float(input('Enter length of edge3: '))

#checks user input for validity
#if valid print output
#else print out error statement
if (edge1+edge2)>edge3 and (edge2+edge3)>edge1 and (edge1+edge3)>edge2:
    perimeter = edge1 + edge2 + edge3
    print('The perimeter is', perimeter)
else:
    print('Perimeter cannot be calculated: the input is invalid')
