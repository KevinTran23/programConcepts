#Ethan Tracy(Driver)U806388874 Kevin (Navigator)U56161476
#participation 50/50

#Angle of ramp

#Take input of mass of cart as well as force required to push, calculate and output angle of ramp

temperature = float(input('Enter the temperature in Fahrenheit: '))
#validating inputs, this will keep asking for valid inputs until parameter is fulfilled
while temperature < -58 or temperature > 41:
    print('Temperature must be between -58F and 41F')
    temperature = float(input('Please re-enter the temperature in Fahrenheit: '))

# asking for user input for speed value
speed = float(input('Enter the wind speed in miles per hour: '))
#validating the speed input
while speed <= 2:
    print('Wind speed must be greater than or equal to 2')
    speed = float(input('Please re-enter the temperature in Fahrenheit: '))

#calculations for wind chill
windChill = 35.74 + (.6215 * temperature) - (35.75 * (speed ** .16)) + (.4275 * temperature * (speed ** .16))
#print statement for finished calculation
print('The wind chill index is {:.3f}'.format(windChill))



