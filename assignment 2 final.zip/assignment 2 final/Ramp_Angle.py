#Ethan Tracy(Driver)U806388874 Kevin (Navigator)U56161476
#Participation: 50/50
#Angle of ramp


#Take input of mass of cart as well as force required to push, calculate and output angle of ramp
#import math
import math
#set constants
GRAVITY = 9.8

# Take input and set to vars
mass = float(input('Enter the mass of the cart(in kg): '))
force = float(input('Enter the force to push the cart(in N): '))

#calculate formula. Split into two parts for simplicity sake
sinTheta = force/(mass*GRAVITY)
theta = math.degrees(math.asin(sinTheta))

#Output formated calculation
print('The angle of the ramp is {:.1f} degrees'.format(theta))
