#Ethan Tracy(Navigator)U806388874 Kevin (Driver)U56161476
#participation: 50/50

#Software Sales

#assigning the user's input for amount of packages purchased
num_pack = float(input('Enter the number of packages purchased: '))
# calculating the total cost
total_amount = num_pack * 99
#assigning discounts and how to calculate discounted value
disc_10 = total_amount * 0.1
disc_20 = total_amount * 0.2
disc_30 = total_amount * 0.3
disc_40 = total_amount * 0.4
# using bounds to establish If statements and using elif to catch other conditions and ending with else as a trailing statement to catch
# reassigning the total_amount variable so it correctly calculates based on the user's input
if num_pack >= 10 and num_pack <= 19:
        print('Discount amount @ 10%:$','{:.2f}'.format(disc_10))
        total_amount = (total_amount) - (disc_10)
        print('Total Amount:$','{:.2f}'.format(total_amount))

elif num_pack >= 20 and num_pack <= 49:
        print('Discount amount @ 20%:$','{:.2f}'.format(disc_20))
        total_amount = (total_amount) - (disc_20)
        print('Total Amount:$','{:.2f}'.format(total_amount))

elif num_pack >= 50 and num_pack<= 99:
        print('Discount amount @ 30%:$','{:.2f}'.format(disc_30))
        total_amount = (total_amount) - (disc_30)
        print('Total Amount:$','{:.2f}'.format(total_amount))

elif num_pack >= 100:
        print('Discount amount @ 40%:$','{:.2f}'.format(disc_40))
        total_amount = (total_amount) - (disc_40)
        print('Total Amount:$','{:.2f}'.format(total_amount))
# program will check input and use the corresponding if/elif statement to calculate the discount and the total amount
else:
        print('Discount amount @ 0%:$ 0.00')
        print('Total Amount:$','{:.2f}'.format(total_amount))
# catches inputs that don't apply a discount

