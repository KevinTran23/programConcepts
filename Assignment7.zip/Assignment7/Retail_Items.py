# Kevin Tran (navigator) U56161476 Ethan Tracy (driver) U80638874
# Participation 50/50
# Class that models retail items had item type, amount, and price attributes

# creating class
class Retail_Item:
    def __init__(self, item='', amnt=0, price=0.0):  # constructor with default values
        self.__typeOfItem = item  # values are hidden with __
        self.__amountInv = amnt
        self.__priceOfItem = price

    def __str__(self):  # string method using string formats and field width
        return f'{self.__typeOfItem:<12} {self.__amountInv:^19} ${self.__priceOfItem: <8}'


def main():  # creating main and organizing program

    # gathering user input of item 1
    name = input('Name of item 1: ')
    amount = int(input('Amount of item 1: '))
    price = float(input('Price of item 1: '))

    item1 = Retail_Item(name, amount, price)  # creating object 1

    print()
    # gathering input of item 2
    name2 = input('Name of item 2: ')
    amount2 = int(input('Amount of item 2: '))
    price2 = float(input('Price of item 2: '))

    item2 = Retail_Item(name2, amount2, price2)  # creating object 2

    print()

    # printing output with formatted strings and field width
    print('Here is the summary of the items you added:')
    print(f"{'Item':<15} {'Amount':^15} {'Price': <10}")
    print('-'*39)
    print(item1)
    print(item2)


main()  # calling main
