# Kevin Tran (Driver) U56161476 Ethan Tracy (navigator) U80638874
# Participation 50/50
# Class that models pet, has name type and age attributes

# creating pet class
class Pet:
    def __init__(self):  # constructor with hidden values from user with __
        self.__name = 'None Provided'
        self.__type = 'None Provided'
        self.__age = 0

    # setters
    # modifies default variables with user input
    def setName(self, n):
        self.__name = n

    def setType(self, t):
        self.__type = t

    def setAge(self, a):
        self.__age = int(a)

    # getter
    # returns value in respect to specific object
    def getName(self):
        return self.__name

    def getType(self):
        return self.__type

    def getAge(self):
        return self.__age

    def __str__(self):  # string method for printing
        return f'Name of pet: {self.__name}\nType of pet: {self.__type}\nAge of pet: {self.__age}'


def main():  # creating main for organizing program

    myPet = Pet()  # object is created

    print('A pet object has been created. Here is the initial information about the pet')
    print(myPet)

    # now updating object with user input
    print('Let\'s update the information for a pet!')
    # gathering user input
    myPet.setName(str(input('Enter the pet\'s name: ')))
    myPet.setType(str(input('Enter the type of animal: ')))
    myPet.setAge(int(input('Enter the pet\'s age: ')))

    print('Here is the update information about the pet: ')
    print(myPet)  # printing str method with user inputs


main()  # calling main
