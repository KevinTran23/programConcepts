#Ethan Tracy (U80638874) Kevin Tran (U56161476)

#Kevin (Driver) Ethan (Navigator)
#Slope of a line
#Calculates slope of a line between 2 points given 2 pairs of x,y coordinates
#Participation: 50/50
print('Slope of a line -------------------\n')

#taking user inputs, assigning variables and providing a prompt for user
x_1=float(input('Enter the x coordinate for the first point:'))
y_1=float(input('Enter the y coordinate for the first point:'))
x_2=float(input('Enter the x coordinate for the second point:'))
y_2=float(input('Enter the y coordinate for the second point:'))
#x_1, x_2, y_1, y_2 = 1, 2, 1, 2 #testing values

#calculating slope using the formula
slope=(y_2-y_1)/(x_2-x_1)

#outputing results with formatted string
print('The slope for the line that connects two points (',x_1,',',y_1,') and (',x_2,',',y_2,') is ','{:.5f}'.format(slope),sep='')

