#Ethan Tracy (U80638874) Kevin Tran (U56161476)

#Kevin (Driver) Ethan (Navigator)
#Runway length
#Finds min length of runway required for takeoff, given take off speed and take off acceleration
#Participation: 50/50
print('\n\nRunway Length -------------------\n')
#taking user inputs
speed=float(input('Enter the plane\'s take off speed in m/s: '))
accel=float(input('Enter the plane\'s take off acceleration in m/s**2: '))
#speed, accel = 1, 1 #testing values

#assigning length with the formula
length=(speed**2)/(2*accel)
#outputting the calculation in formatted string
print('The minimum runway length needed for this airplane is','{:.4f}'.format(length),'meters.')

