#Ethan Tracy (U80638874) Kevin Tran (U56161476)

#Ethan(Driver) Kevin(Navigator)
#Tip Calculator
#Calculates tip given subtotal and percent of tip you would like to take
#Participation: 50/50
print('\n\nTip Calculator -------------------\n')

# Take user input and assign to vars
subtotal = float(input('Enter subtotal: $'))
tipPercent = float(input('Enter tip amount(as %): '))
#subtotal, tipPercent = 1, 1 #testing values

# Calculate tip
tip = subtotal * (tipPercent/100)

# Output values in formatted strings
print('Subtotal: $ {:,.2f}'.format(subtotal))
print('Tip: $ {:.2f}'.format(tip))
# To get total just add tip and subtotal together
print('Total: $ {:,.2f}'.format(subtotal+tip))
