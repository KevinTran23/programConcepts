#Ethan Tracy (U80638874) Kevin Tran (U56161476)

#import math for last script
import math
#Ethan(Driver) Kevin(Navigator)
#Area of a Hexagon
#Finds area of hexagon given side length
#Participation: 50/50

print('\n\nArea of a Hexagon -------------------\n')

# Take user input and assign to vars
side = float(input('Enter the side length of the hexagon: '))

# Calculate area using given formula
area = (((3 * math.sqrt(3)) / 2) * pow(side, 2))

# Output area using formatted string
print('The area of a hexagon with a side length of {:} is {:.3f}'.format(side, area))
