'''Rock Paper Scissors'''
#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50

import random #importing random functions that will be used throughout the program

choices = ('Rock', 'Paper', 'Scissors', 'Spock', 'Lizard') #list of choices the computer will pick from and be used for validation

#tuples using the corresponding win condition. ex. rock will beat whatever is in the tuple of rockWin
rockWin = ('Lizard', 'Scissors')
paperWin = ('Rock', 'Spock')
scissorsWin = ('Lizard', 'Paper' )
spockWin = ('Scissors', 'Rock')
lizardWin = ('Spock', 'Paper')

#dictionary that will be referenced in the if statements. if the computer choice is in the user's wincon, player wins

winCon = {'Rock': rockWin,
          'Paper': paperWin,
          'Scissors': scissorsWin,
          'Spock': spockWin,
          'Lizard': lizardWin}

#tuple for what to print depending on the index of the referenced choice. If computer's choice is in the wincon of user,
# grab the index of where computerchoice is and then use the same index in the winstatement.
rockSay = ('crushes', 'crushes')
paperSay = ('covers', 'disproves')
scissorSay = ('decapitates', 'cuts')
spockSay = ('crushes', 'vaporizes')
lizardSay = ('poisons', 'eats')

#will be referencing this dictionary to print out the statement depending on who wins
winStatement = {'Rock': rockSay,
                'Paper': paperSay,
                'Scissors': scissorSay,
                'Spock': spockSay,
                'Lizard': lizardSay}

#will be indexing as loop goes on
games = 0
win = 0
lose = 0
tie = 0

#while loop and start of program
while games >= 0:
    print('Let\'s Play Rock, Paper, Scissors, Spock, Lizard!')
    computerChoice = random.choice(choices)# computer randomly choosing from the tuple 'choices'
    playerChoice = str(input('Enter your choice: ')).title()#user input


    while playerChoice not in choices:#input validation
        playerChoice = str(input('Invalid response: ')).title()

    games += 1#when user input is accepted, game will begin so it will update var 'game'
    if computerChoice == playerChoice:
        tie += 1
        print(f'Computer chose {computerChoice}.')
        print('It\'s a tie!')

    elif computerChoice in winCon[playerChoice]:#if computer's choice is in player choice's tuple, player wins
        win += 1
        print(f'Computer chose {computerChoice}')
        part1 = winCon[playerChoice].index(computerChoice)#looks for the index where computer's choice is found in corresponding tuple
        part2 = winStatement[playerChoice][part1]#in the winstatement dictionary, look for the player choice's winstatement based on the same index
        print(f'{playerChoice} {part2} {computerChoice}')#putting the statement together
        print('Player wins!')

    else:# if player choice is in the computer's choice wincon, player loses
        lose += 1
        print(f'Computer chose {computerChoice}')
        part1 = winCon[computerChoice].index(playerChoice)#same thing but this time doing it for computer's choice
        part2 = winStatement[computerChoice][part1]
        print(f'{computerChoice} {part2} {playerChoice}')
        print('Computer wins!')

    decision = str(input('Would you like to play again? yes or no: ')).lower()
    valid = ('yes','no')
    while decision not in valid:#loop for if the player wants to keep playing/ this is the validation portion for yes/no
        decision = str(input('Invalid response, would you like to play again? (yes or no): ')).lower()
    if decision == 'yes':
        continue#resumes the loop
    else:
        break#breakes the loop

#prints out the updated variables
print(f'Number of games played: {games}')
print(f'Games you won: {win}')
print(f'Games the computer won: {lose}')
print(f'Tie games: {tie}')





