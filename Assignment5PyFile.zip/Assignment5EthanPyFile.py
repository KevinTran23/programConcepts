#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50
# Tortoise and Hare program simulates race between tortise and hare using random numbers and probability

#import random as rm makes life easier not having to type random as much
import random as rm

# Main function
# Global Constants: RACE_LENGTH
# Global Variables: tortiseScore, hareScore
def main():
    
    # Set vars as  globals so they can be used in other functions
    global RACE_LENGTH, tortoiseScore, hareScore

    # Global Constant defining the Length of the Race
    RACE_LENGTH = 50

    # Global Var holding tortoise score, Global Var holdig Hare score
    tortoiseScore, hareScore = 0, 0

    # Var holding current 'sec' or iteration of the game
    currentSec = 0

    print(f'ON YOUR MARK...\nGET SET...\nGO!!!!!!\nAND THEY\'RE OFF!\n')

    #Game Loop, runs forever until broken outof
    while True:
        # Call iterateGame function and set x equal to its return
        breakLoop = iterateGame()

        # Increase sec or increment count by 1
        currentSec += 1

        # if x is a truthy value (1 is expected) then break out of the while loop
        if breakLoop:
            break

    print(f'Time of race: {currentSec} seconds')



# iterateGame is a function that runs through 1 iteration of the game
# INPUT: NONE
# GLOBALS: tortoiseScore, hareScore
# CALCUALTION: runs move tortoise and hare functions, determines if either tortoiseScore or hareScore are the same or over 50 
# OUTPUT: -1, a truthy value if either tortoise or hare have score over 50, else 'None'/void
def iterateGame():

    # Grab global variables, not needed to use globals but it makes life easier in this case
    global tortoiseScore, hareScore

    # Call movePlayer functions and update player scores
    tortoiseScore, hareScore = moveTortoise(tortoiseScore), moveHare(hareScore)

    # Call printRaceTrack
    printRaceTrack(tortoiseScore, hareScore)

    # Check for win conditions on either player, if so return 1
    if tortoiseScore >= 50 or hareScore >= 50:
        # If tortoise is higher then or equal to hare print Tortoise wins, else hare wins.
        if tortoiseScore >= hareScore:
            print('Tortoise wins. Yay')
        else:
            print('Hare wins. Yay')
        return 1 # A truthy value, normally associated with successful completion (-1 being fail return normally)



# moveTortoise is a function that moves the tortoise character based on random chance
# INPUT: INT = current position of tortoise character 
# CALCUALTION: next postition of tortoise based on random number generator and probabilities
# OUTPUT: INT = next position of the tortoise character
def moveTortoise(position):
    # Random integer from 1 to 11 exclusive (1-10)
    # I use randrange since I am using range in my cacluations, it makes more logical sense
    roll = rm.randrange(1,11)

    # 50% chance to move 3 forward (5/10)
    if roll in range(1,6):
        return position + 3

    # 20% chance to move 5 backward (2/10)
    elif roll in range(6,8):
        # If statement checks to see if the move makes the position go below 0, if not return proper position else return 0
        if position - 5 >= 0:
            return position - 5
        else:
            return 0

    # 30% chance to move 1 forward (3/10)
    elif roll in range(8,11):
        return position + 1

    else:
        # failsafe condition, returns int to satisfy output requirements, but prints fail message
        print(f'tortoise FAILED\nRoll = {roll}')
        return -1

        
    
# moveHare is a function that moves the hare character based on random chance
# INPUT: INT = current position of hare character 
# CALCUALTION: next postition of hare based on random number generator and probabilities
# OUTPUT: INT = next position of the hare character
def moveHare(position):

    # Random integer from 1 to 11 exclusive (1-10)
    roll = rm.randrange(1,11)

    # 20% chance to not move (2/10)
    if roll in range(1,3):
        return position 

    # 20% chance to move 7 forward (2/10)
    elif roll in range(3,5):
        return position + 7

    # 10% chance to move 10 backward (1/10)
    elif roll in range(5,6):
        # If statement checks to see if the move makes the position go below 0, if not return proper position else return 0
        if position - 10 >= 0:
            return position - 10
        else:
            return 0

    # 30% chance to move 1 forward(3/10)
    elif roll in range(6,9):
        return position + 1

    # 20% chance to move 10 backward (2/10)
    elif roll in range(9,11):
        # If statement checks to see if the move makes the position go below 0, if not return proper position else return 0
        if position - 2 >= 0:
            return position - 2
        else:
            return 0

    else:
        # failsafe condition, returns int to satisfy output requirements, but prints fail message
        print(f'HARE FAILED\nRoll = {roll}')
        return -1
   


# raceTrack is a function that prints the stats of tortoise and hare to the screen
# INPUT: INT = current position of tortoise character, INT = current position of the hare character
# CALCUALTION: prints char H and T on the same line in the correct position in relation to their position in the race using concatination
# OUTPUT: VOID
def printRaceTrack(tortoiseScore,hareScore):

    # Clamp animal scores to 50 incase one of the animals moves past the finish line
    tortoiseScore, hareScore = clamp(tortoiseScore, 1, 50), clamp(hareScore, 1, 50)
    #print(tortoiseScore,hareScore)

    #For statment running length of race and printing T, H, or ' ' by comparing scores against itorator
    for i in range(1,RACE_LENGTH+1):
        if i == tortoiseScore and i == hareScore:
            print('OW!',end='')
        elif i == tortoiseScore:
            print('T',end='')
        elif i == hareScore:
            print('H',end='')
        else:
            print(' ',end='')
    print()

# clamp is a function that clamps a given value bettween a higher and lower bound inclusive
# INPUT: INT = The value to be clamped, INT = The lowest value that you want the output to be, INT = The highest value you want the output to be
# CALCUALTION: Selects the min value between VALUE and UPPER, then selects the max bettween that number and LOWER
# OUTPUT: INT = the clamped value between or equal to higher and lower
def clamp(value, lower, upper):
    return max(min(value,upper), lower)


# This is a much cleaner and versitile approach to printing the racetrack, depreciated as it does not use for loop
'''
def printStats(tortoiseScore, hareScore):
    #Fills a string with RACE_LENGTH - 2 spaces, minus 2 to leave from for H and T chars
    STRING_WITH_SPACES = ' ' * (RACE_LENGTH - 2)

    # Converts string to list for manipulation
    trackList = list(STRING_WITH_SPACES)

    # Inserts H and then T into the list according to their score as an index
    trackList.insert(hareScore, 'H')
    trackList.insert(tortoiseScore, 'T')

    # Joins the list back into a string for printing
    trackVisualizationString = ''.join(trackList)

    print(trackVisualizationString)

    # Finish line to help visualize where the game objects are in relation to the end condition
    finishLine = '|'
    finishLine = ''
    finishLine = finishLine + ' ' * (RACE_LENGTH)
    finishLine = finishLine + '|'
    print(finishLine)
'''
 

if __name__ == '__main__':
    main()