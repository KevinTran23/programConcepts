#Ethan Tracy U80638874 (pilot and Co pilot) Kevin Tran U56161476 (pilot and Co pilot)
#participation 50/50

#Program converts english sentence into morse code

# tuple containing morse code
tupMorse = (' ',
            '.-',
            '-...',
            '-.-.',
            '-..',
            '.',
            '..-.',
            '--.',
            '....',
            '..',
            '.---',
            '-.-',
            '.-..',
            '--',
            '-.',
            '---',
            '.--.',
            '--.-',
            '.-.',
            '...',
            '-',
            '..-',
            '...-',
            '.--',
            '-..-',
            '-.--',
            '--..',
            '.----',
            '..---',
            '...--',
            '....-',
            '.....',
            '-....',
            '--...',
            '---..',
            '----.',
            '-----',
            '--..--',
            '.-.-.-',
            '..--..',
            '-..-.',
            '-....-',
            '-.--.',
            '-.--.-')

#test = '....-. -..... .--.....--..-. .--.-... ....-..-----..-- -.....-. .--.....-- .--.-... -..... --.-..-....-..----...--..' #validation

#word = 'If the answer was 42, then what was the question?'.lower() #validation

word = str(input('Enter the string to be converted to Morse code: ')).lower() #take input and set to lower case


# for loop, loops through characters in the string
for char in word:#'for each character in the string' do this
    #if-elif-else checks string char then prints respective morese code
    if char == ' ':
        print(' ', end='')
    elif char == 'a':
        print(tupMorse[1], end='')
    elif char == 'b':
        print(tupMorse[2], end='')
    elif char == 'c':
        print(tupMorse[3], end='')
    elif char == 'd':
        print(tupMorse[4], end='')
    elif char == 'e':
        print(tupMorse[5], end='')
    elif char == 'f':
        print(tupMorse[6], end='')
    elif char == 'g':
        print(tupMorse[7], end='')
    elif char == 'h':
        print(tupMorse[8], end='')
    elif char == 'i':
        print(tupMorse[9], end='')
    elif char == 'j':
        print(tupMorse[10], end='')
    elif char == 'k':
        print(tupMorse[11], end='')
    elif char == 'l':
        print(tupMorse[12], end='')
    elif char == 'm':
        print(tupMorse[13], end='')
    elif char == 'n':
        print(tupMorse[14], end='')
    elif char == 'o':
        print(tupMorse[15], end='')
    elif char == 'p':
        print(tupMorse[16], end='')
    elif char == 'q':
        print(tupMorse[17], end='')
    elif char == 'r':
        print(tupMorse[18], end='')
    elif char == 's':
        print(tupMorse[19], end='')
    elif char == 't':
        print(tupMorse[20], end='')
    elif char == 'u':
        print(tupMorse[21], end='')
    elif char == 'v':
        print(tupMorse[22], end='')
    elif char == 'w':
        print(tupMorse[23], end='')
    elif char == 'x':
        print(tupMorse[24], end='')
    elif char == 'y':
        print(tupMorse[25], end='')
    elif char == 'z':
        print(tupMorse[26], end='')
    elif char == '1':
        print(tupMorse[27], end='')
    elif char == '2':
        print(tupMorse[28], end='')
    elif char == '3':
        print(tupMorse[29], end='')
    elif char == '4':
        print(tupMorse[30], end='')
    elif char == '5':
        print(tupMorse[31], end='')
    elif char == '6':
        print(tupMorse[32], end='')
    elif char == '7':
        print(tupMorse[33], end='')
    elif char == '8':
        print(tupMorse[34], end='')
    elif char == '9':
        print(tupMorse[35], end='')
    elif char == '0':
        print(tupMorse[36], end='')
    elif char == ',':
        print(tupMorse[37], end='')
    elif char == '.':
        print(tupMorse[38], end='')
    elif char == '?':
        print(tupMorse[39], end='')
    else:
        print('[not valid char]', end='')
#print()
#print(test) #validation
