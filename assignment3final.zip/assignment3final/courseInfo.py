#Ethan Tracy U80638874 (Pilot and Co Pilot) Kevin Tran U56161476 (Pilot and Co Pilot)
#participation 50/50

#Course finder program, Takes course prefix and number, outputs name, professor, and time

ask = str(input('Enter a course number: ')) #asking for the user's course number

courseNum = ('COP 2510','EGN 3000L','MAC 2281','MUH 3016','PHY 2048') #course numbers stored in a tuple

'''
Creation of dictionary
Key = Class number with 3 letter prefix : 
Value = Tuple containing Name, Professor, and Meeting Time
'''
courseSearch = {'COP 2510' : ('Programming Concepts','Z.Beasley','MW 12:30pm - 1:45pm'),
            'EGN 3000L' : ('Foundation of Engineering Lab','J. Anderson','TR 11:00am - 12:15pm'),
            'MAC 2281' : ('Calculus 1','A. Makayrus','MW 9:30am - 10:45am'),
            'MUH 3016' : ('Survey of Jazz','A. wilkins','online asynchronus'),
            'PHY 2048' : ('General Physics 1','G. Pradhan','TR 5:00pm - 6:15pm')}


# Validating input by checking input against courseNum tuple
if ask not in courseNum:
    print(f'{ask} is an invalid course number.')


#printing output, using input to as key to pull from dictionary
else:
    print('The course details are:')
    print('Course Name: ',courseSearch[ask][0])
    print('Instructor: ',courseSearch[ask][1])
    print('Class Times: ',courseSearch[ask][2])
