#Ethan Tracy U80638874 (pilot and Co pilot) Kevin Tran U56161476 (pilot and Co pilot)
#participation 50/50

#Total sales program prompts user for sales for every day of the week. calcuates and outputs total, min, max

days = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')
#dates in a tuple
sales = [ ] #empty list

#this is saying for all lvariables in days, we'll call 'n', print the following inputs
for day in days:
   sale = float(input(f'Enter the sales for {day}: '))
   while sale < 0:# while goes first because you want to filter out the bad inputs
       sale = float(input(f'Re-enter the sales for {day}: '))
   if sale > 0:
       sales.append(sale)


#calculate sum, min, and max using built in fuctions
# output with f strings


print(f'Total sales is: ${sum(sales):,.2f}')
print(f'The minimum sale amount was: ${min(sales):,.2f}')
print(f'The maximum sale amount was: ${max(sales):,.2f}')



