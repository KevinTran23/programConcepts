#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50
#Decription: This program take user defined text file, reads and translates its contents to piglatin, and saves that to a user defined text file

# Main function
# Global Constants: LOWER_A_TO_LOWER_Z
# Global Variables: 
def main():
    global LOWER_A_TO_LOWER_Z

    # This global constant contains a range object from the decimal value of lowercase a to the decimal value of lowercase z plus 1 to make it inclusive
    LOWER_A_TO_LOWER_Z = range(ord('a'),(ord('z')+1))

    # Collect input from user, no input validation
    TEXT_INPUT_NAME = input('Please enter the name of your input file. (With the extenstion .txt included please): ')

    TEXT_OUTPUT_NAME = input('Please enter the name of your output file. (With the extenstion .txt included please): ')

    #TEXT_INPUT_NAME = 'Assignment6/desiderata.txt' # Hardcoded file paths to make testing easier

    #TEXT_OUTPUT_NAME = 'Assignment6/pigOutput.txt'

    wholeText = readFile(TEXT_INPUT_NAME)

    writeFile(TEXT_OUTPUT_NAME, pigListOfStr(wholeText))


# pigListOfStr is a function that takes a list of strings, seperates the strings one at a time, and passes them to pigStr function
# INPUT: LIST (or other enumeratable) = containing Strings
# CALCULATION: calles pigStr and passes a single str at a time to it
# OUTPUT: STRING = by joining all of the edited strings seperated by newline characters
def pigListOfStr(listOfStrs):
    for (lineIndex,line) in enumerate(listOfStrs):
        listOfStrs[lineIndex] = pigStr(line)
    return '\n'.join(listOfStrs) # joins list into a string with newline char because each str in the list is its own line, this retains that property

# pigStr is a function that takes a string, seperates the words, and passes them to pigWord function
# INPUT: STRING
# CALCULATION: calles pigWord and passes a single word at a time to it
# OUTPUT: STRING = created by joining all of the edited words seperated by a space
def pigStr(str):
    words = str.split()
    for (wordIndex,word) in enumerate(words):
        words[wordIndex] = pigWord(word)
    return ' '.join(words) # joins list into a string with space char between words because a sentence has a space between every word


# pigWord is a function that takes a word, seperates the letters, and translates them to pig latin
# GLOBALS: LOWER_A_TO_LOWER_Z
# INPUT: STRING = containing single word
# CALCULATION: seperates word into list, moves first letter to back, adds a and y to end. sucessfully retains captitalization as well as punctuation
# OUTPUT: STRING = string containing one word
def pigWord(word):
    # pigExtra is a list containing the extra two chars needed to convert english to pig latin
    pigExtra = ['a','y']

    letters = list(word)

    # This if statement checks to see if the first letter is captial, if so make it lowercase and set the second letter to upper case
    if ord(letters[0]) + 32 in LOWER_A_TO_LOWER_Z:
        letters[0] = chr(ord(letters[0])+32)
        letters[1] = chr(ord(letters[1])-32)

    # add the letter at the beginning of the list, to the end of the list
    letters.append(letters[0])

    # remove the letter at the beginning of the list
    letters.pop(0)

    # add the pig extra list containing two chars
    letters.extend(pigExtra)

    # this for loop handles punctuation, if it finds a value not in the range of allowed chars, it will append it to the list and remove its first occurance
    for letter in letters:
        if ord(letter.lower()) not in LOWER_A_TO_LOWER_Z:
            letters.append(letter)
            letters.remove(letter)
    
    return ''.join(letters) # This joins the letter together into a single string with nothing between them.


# readFile is a function that takes a file path, opens the file and reads its contents as a list of strings
# INPUT: STRING = containing filepath and name
# CALCULATION: opens the file, reads a list of strings from the file, and closes the file
# OUTPUT: List = of strings representing file contents
def readFile(filePath):
    CURRENT_TEXT_FILE = open(filePath, 'r')
    # I use readlines here as it is gives me better posistional data to work with, we used it in the zybook lessons so I think its ok?
    wholeFileText = CURRENT_TEXT_FILE.readlines()
    CURRENT_TEXT_FILE.close()
    return wholeFileText


# writeFile is a void function that takes a file path and string, opens the file and writes the string given to the files
# INPUT: STRING = containing filepath and name, STRING = string to write to file
# CALCULATION: opens the file, writes the string passed to the file, and closes the file
# OUTPUT: VOID
def writeFile(filePath, strToWrite):
    CURRENT_TEXT_FILE = open(filePath, 'w')
    CURRENT_TEXT_FILE.write(strToWrite)
    CURRENT_TEXT_FILE.close()



if __name__ == "__main__":
    main()