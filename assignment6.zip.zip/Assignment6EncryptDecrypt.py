#Ethan Tracy U80638874 (Pliot and Co Pliot) Kevin Tran U56161476 (Pliot and Co Pliot)
#participation 50/50
#Decription: This program take user defined text file, reads and encrypts its contents, and saves that to a user defined text file

# Main function
# Global Constants: ENCRYPT_CODE
# Global Variables: 
def main():
    # Set constant as global so it does not need to be passed down multiple function calls to be used
    global ENCRYPT_CODE

    # Dictionary containing encryption scheme
    ENCRYPT_CODE =  {
        'A':')','a':'0','B':'(','b':'9','C':'*','c':'8',
        'D':'&','d':'7','E':'^','e':'6','F':'%','f':'5',
        'G':'$','g':'4','H':'#','h':'3','I':'@','i':'2', 
        'J':'!','j':'1','K':'Z','k':'z','L':'Y','l':'y', 
        'M':'X','m':'x','N':'W','n':'w','O':'V','o':'v', 
        'P':'U','p':'u','Q':'T','q':'t','R':'S','r':'s', 
        'S':'R','s':'r','T':'Q','t':'q','U':'P','u':'p', 
        'V':'O','v':'o','W':'N','w':'n','X':'M','x':'m', 
        'Y':'L','y':'l','Z':'K','z':'k','!':'J','1':'j', 
        '@':'I','2':'i','#':'H','3':'h','$':'G','4':'g', 
        '%':'F','5':'f','^':'E','6':'e','&':'D','7':'d', 
        '*':'C','8':'c','(':'B','9':'b',')':'A','0':'a', 
        ':':',',',':':','?':'.','.':'?','<':'>','>':'<', 
        "'":'"','"':"'",'+':'-','-':'+','=':';',';':'=',
        '{':'[','[':'{','}':']',']':'}'} 


    # Collect input from user, no input validation
    TEXT_INPUT_NAME = input('Please enter the name of your input file. (With the extenstion .txt included please): ')

    TEXT_OUTPUT_NAME = input('Please enter the name of your output file. (With the extenstion .txt included please): ')

    #TEXT_INPUT_NAME = 'Assignment6/desiderata.txt' # Hardcoded file paths to make testing easier

    #TEXT_OUTPUT_NAME = 'Assignment6/encryptOutput.txt'

    #print(wholeText)

    # Call readfile and save its value 
    wholeText = readFile(TEXT_INPUT_NAME)
    
    # Call writefile and pass it the output file as well as call encryptListOfStr and pass it whole text to get a str to write
    writeFile(TEXT_OUTPUT_NAME, encryptListOfStr(wholeText))



# encryptListOfStr is a function that takes a list of strings, seperates the strings one at a time, and passes them to encryptStr function
# INPUT: LIST (or other enumeratable) = containing Strings
# CALCULATION: calles encryptStr and passes a single str at a time to it
# OUTPUT: STRING = by joining all of the edited strings seperated by newline characters
def encryptListOfStr(listOfStrs):
    for (lineIndex,line) in enumerate(listOfStrs):
        listOfStrs[lineIndex] = encryptStr(line)
    return '\n'.join(listOfStrs) # joins list with newline char because each str is its own line, this retains that property

# encryptStr is a function that takes a string, seperates the words, and passes them to encryptWord function
# INPUT: STRING
# CALCULATION: calles encryptWord and passes a single word at a time to it
# OUTPUT: STRING = created by joining all of the edited words seperated by a space
def encryptStr(str):
    words = str.split()
    for (wordIndex,word) in enumerate(words):
        words[wordIndex] = encryptWord(word)
    return ' '.join(words) # joins list with space char because a sentence has a space between every word

# encryptWord is a function that takes a word, seperates the letters, and encrypts them using the dictionary
# GLOBALS: ENCRYPT_CODE
# INPUT: STRING = containing single word
# CALCULATION: seperates word into list, edits each char using dictionary provided, and joins the list with nothing inbetween the chars
# OUTPUT: STRING = string containing one word
def encryptWord(word):
    letters = list(word)
    for (letterIndex,letter) in enumerate(letters):
        letters[letterIndex] = ENCRYPT_CODE[letter] # This uses the dictionary to replace the char at the index with its respective encrypted char
    return ''.join(letters) # joins list with empty string because a word does not have spaces between its chars

# readFile is a function that takes a file path, opens the file and reads its contents as a list of strings
# INPUT: STRING = containing filepath and name
# CALCULATION: opens the file, reads a list of strings from the file, and closes the file
# OUTPUT: List = of strings representing file contents
def readFile(filePath):
    CURRENT_TEXT_FILE = open(filePath, 'r')
    # I use readlines here as it is gives me better posistional data to work with, we used it in the zybook lessons so I think its ok?
    wholeFileText = CURRENT_TEXT_FILE.readlines()
    CURRENT_TEXT_FILE.close()
    return wholeFileText

# writeFile is a void function that takes a file path and string, opens the file and writes the string given to the files
# INPUT: STRING = containing filepath and name, STRING = string to write to file
# CALCULATION: opens the file, writes the string passed to the file, and closes the file
# OUTPUT: VOID
def writeFile(filePath, strToWrite):
    CURRENT_TEXT_FILE = open(filePath, 'w')
    CURRENT_TEXT_FILE.write(strToWrite)
    CURRENT_TEXT_FILE.close()
    
    

if __name__ == '__main__':
    main()


# This is an alternative way to encrypt a list of strings leaving it in just for the sake of having more options if I want to come back and try to reuse some of this code
'''
def encryptListOfStr(listOfStrs):
    for (lineIndex,line) in enumerate(listOfStrs):
        words = line.split()
        for (wordIndex,word) in enumerate(words):
            words[wordIndex] = encryptWord(word)
        listOfStrs[lineIndex] = ' '.join(words)
    return '\n'.join(listOfStrs)
'''